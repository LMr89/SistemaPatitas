package com.patitas.api.app.dominio.modelo.peticion;

public class ClientePeticion {

}
